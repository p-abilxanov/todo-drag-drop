export function Encrypt(theText) {
    let output = new String;
    let Temp = new Array();
    let Temp2 = new Array();
    let TextSize = theText.length;
    
    for (let i = 0; i < TextSize; i++) {
        let rnd = Math.round(Math.random() * 122) + 68;
        Temp[i] = theText.charCodeAt(i) + rnd;
        Temp2[i] = rnd;
    }

    for (let i = 0; i < TextSize; i++) {
        output += String.fromCharCode(Temp[i], Temp2[i]);
    }
    return output;
}

export function unEncrypt(theText) {
    let output = new String;
    let Temp = new Array();
    let Temp2 = new Array();
    let TextSize = theText.length;

    for (let i = 0; i < TextSize; i++) {
        Temp[i] = theText.charCodeAt(i);
        Temp2[i] = theText.charCodeAt(i + 1);
    }
    for (let i = 0; i < TextSize; i = i + 2) {
        output += String.fromCharCode(Temp[i] - Temp2[i]);
    }
    return output;
}

let database = [{
        id: 1,
        text: "Lorem ipsum dolor sit amet.",
        date: new Date(2020, 1, 22),
        status: 'process',
        completed: false
    },
    {
        id: 2,
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        date: new Date(2021, 3, 14),
        status: 'important',
        completed: true
    },
    {
        id: 3,
        text: "Dolor sit amet consectetur adipisicing elit",
        date: new Date(2021, 9, 11),
        status: 'done',
        completed: false
    },
    {
        id: 4,
        text: "Sit amet consectetur adipisicing elit",
        date: new Date(2022, 1, 14),
        status: 'process',
        completed: false
    }
]
let user = [{
    id: 1,
    login: 'user1',
    password: 'user1'
}, {
    id: 2,
    login: 'admin',
    password: 'admin'
}, {
    id: 3,
    login: 'user2',
    password: 'user2'
}]
let request = window.indexedDB.open('TODO', 2);

request.onerror = (e) => {
    console.error(`IndexedDB error: ${request.error}`);
}

request.onupgradeneeded = (e) => {
    let db = e.target.result;

    let objectStore1 = db.createObjectStore('tasks', {
        keyPath: 'id'
    });

    let objectStore2 = db.createObjectStore('users', {
        keyPath: 'id'
    });

    database.forEach((e) => {
        objectStore1.add(e);
    })

    user.forEach((e) => {
        e.login = Encrypt(e.login);
        e.password = Encrypt(e.password);
        objectStore2.add(e);
    })
}