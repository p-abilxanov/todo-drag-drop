const {
    unEncrypt,
    Encrypt
} = require("./db");

const showPasswordBtn = document.getElementById('password-show');
const generatePasswordBtn = document.getElementById('password-generate');
const confirmPasswordInput = document.getElementById('inputPassword5');
const emailInput = document.getElementById('inputEmail4');
const passwordInput = document.getElementById('inputPassword4');
const infoSaveBtn = document.getElementById('user-info-save-btn');

class Settings {
    generatePassword() {
        let chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let passwordLength = 12;
        let password = "";
        for (let i = 0; i <= passwordLength; i++) {
            let randomNumber = Math.floor(Math.random() * chars.length);
            password += chars.substring(randomNumber, randomNumber + 1);
        }
        return password;
    }

    showPasswordCheck() {
        if (showPasswordBtn.checked) {
            confirmPasswordInput.setAttribute('type', 'text')
            passwordInput.setAttribute('type', 'text')
        } else {
            confirmPasswordInput.setAttribute('type', 'password')
            passwordInput.setAttribute('type', 'password')
        }
    }

    generatePasswordCheck() {
        if (generatePasswordBtn.checked) {
            let generatePasswordValue = this.generatePassword();
            confirmPasswordInput.value = generatePasswordValue;
            passwordInput.value = generatePasswordValue;
            confirmPasswordInput.setAttribute('disabled', 'true')
            passwordInput.setAttribute('disabled', 'true')
        } else {
            confirmPasswordInput.removeAttribute('disabled')
            passwordInput.removeAttribute('disabled')
        }
    }

    infoSave(newEmail, newPassword) {
        let activeUser = localStorage.getItem('active-user').split('[and]')
        let currentUser = unEncrypt(activeUser[0]);

        let request = window.indexedDB.open('TODO');

        request.onsuccess = e => {
            let db = e.target.result;
            let tx = db.transaction('users', 'readwrite').objectStore('users');
            let objectStoreRequest = tx.openCursor();
            objectStoreRequest.onsuccess = e => {
                let cursor = e.target.result

                if (cursor) {

                    if (unEncrypt(cursor.value.login) == currentUser) {
                        let putRequest = tx.put({
                            id: cursor.value.id,
                            login: newEmail,
                            password: newPassword
                        });

                        putRequest.onsuccess = e => {
                            localStorage.setItem('active-user', `${Encrypt(newEmail)}[and]${Encrypt(newPassword)}`);
                        }
                    }

                    cursor.continue()
                }
            }
        }

    }
}

let settings = new Settings();

showPasswordBtn?.addEventListener('click', e => {
    settings.showPasswordCheck()
})

generatePasswordBtn?.addEventListener('click', e => {
    settings.generatePasswordCheck();
})

infoSaveBtn?.addEventListener('click', e => {
    if (emailInput.value != "" && passwordInput.value != "" && confirmPasswordInput.value != "" && confirmPasswordInput.value == passwordInput.value) {
        settings.infoSave(emailInput.value, passwordInput.value)
    } else {
        alert('Try again. Email or password was wrong');
    }

})